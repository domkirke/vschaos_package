# -*- coding: utf-8 -*-
import torch
from torch import nn
from torch.nn import functional as F
from torch import distributions as distrib
from torch.distributions import transforms as transform
from scipy import linalg as splin
import numpy as np

class TemporalFlow(Flow):
    
    def __init__():
        pass